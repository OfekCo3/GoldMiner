// SPDX-FileCopyrightText: 2023 Erin Catto
// SPDX-License-Identifier: MIT

#include "array.h"

#include <stddef.h>

B2_ARRAY_SOURCE( int, b2Int );
